import React from 'react';
import { Calendar, MapPin, ExternalLink } from 'lucide-react';

export const Experience: React.FC = () => {
  const experiences = [
    {
      title: 'Senior Software Developer',
      company: 'Tech Solutions Inc.',
      location: 'San Francisco, CA',
      period: '2022 - Present',
      description: 'Lead development of scalable web applications using modern frameworks and technologies. Collaborate with cross-functional teams to deliver high-quality solutions.',
      achievements: [
        'Improved application performance by 40% through optimization',
        'Led a team of 5 developers on major product releases',
        'Implemented CI/CD pipelines reducing deployment time by 60%'
      ],
      technologies: ['React', 'TypeScript', 'Node.js', 'AWS']
    },
    {
      title: 'Full Stack Developer',
      company: 'Digital Innovations LLC',
      location: 'Austin, TX',
      period: '2020 - 2022',
      description: 'Developed and maintained full-stack applications with focus on user experience and performance. Worked closely with UX/UI designers to implement pixel-perfect designs.',
      achievements: [
        'Built 15+ responsive web applications from scratch',
        'Reduced bug reports by 50% through comprehensive testing',
        'Mentored 3 junior developers and conducted code reviews'
      ],
      technologies: ['Vue.js', 'Python', 'PostgreSQL', 'Docker']
    },
    {
      title: 'Frontend Developer',
      company: 'Creative Agency Pro',
      location: 'New York, NY',
      period: '2018 - 2020',
      description: 'Created engaging user interfaces and interactive experiences for various client projects. Focused on responsive design and cross-browser compatibility.',
      achievements: [
        'Delivered 25+ client projects on time and within budget',
        'Improved website loading speeds by 35% on average',
        'Established front-end coding standards and best practices'
      ],
      technologies: ['JavaScript', 'SASS', 'WordPress', 'Figma']
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Professional Experience
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-indigo-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A journey of continuous growth, learning, and delivering impactful solutions
          </p>
        </div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <div
              key={index}
              className="group bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden"
            >
              <div className="p-8">
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                  <div className="flex-1">
                    <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors duration-300">
                      {exp.title}
                    </h3>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-gray-600 mb-4">
                      <div className="flex items-center gap-2">
                        <ExternalLink size={16} className="text-blue-500" />
                        <span className="font-semibold">{exp.company}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin size={16} className="text-gray-400" />
                        <span>{exp.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar size={16} className="text-gray-400" />
                        <span>{exp.period}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <p className="text-gray-600 leading-relaxed mb-6">
                  {exp.description}
                </p>

                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">Key Achievements</h4>
                  <ul className="space-y-2">
                    {exp.achievements.map((achievement, i) => (
                      <li key={i} className="flex items-start gap-3 text-gray-600">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {exp.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium hover:bg-blue-200 transition-colors duration-200"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};